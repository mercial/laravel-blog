<?php $__env->startSection('main'); ?>

<?php $__env->startSection('title'); ?>
Главная | Блог Владислава Озоровского
<?php $__env->stopSection(); ?>

<!-- banner-area -->
<?php echo $__env->make('frontend.home_all.home_slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- banner-area-end -->

<!-- about-area -->
<?php echo $__env->make('frontend.home_all.home_about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- about-area-end -->

<!-- portfolio-area -->
<?php echo $__env->make('frontend.home_all.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- portfolio-area-end -->

<!-- blog-area -->
<?php echo $__env->make('frontend.home_all.home_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- blog-area-end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mercial/Документы/blog/resources/views/frontend/index.blade.php ENDPATH**/ ?>