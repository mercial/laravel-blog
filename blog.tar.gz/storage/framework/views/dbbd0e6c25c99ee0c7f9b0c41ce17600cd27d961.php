<img src="<?php echo e(asset('logo/logo.png')); ?>" width="100px" >
<?php /**PATH /home/mercial/Документы/blog/resources/views/components/application-logo.blade.php ENDPATH**/ ?>