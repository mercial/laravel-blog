<?php $__env->startSection('main'); ?>

<?php $__env->startSection('title'); ?>
Портфолио | Блог Владислава Озоровского
<?php $__env->stopSection(); ?>
 <main>

            <!-- breadcrumb-area -->
            <section class="breadcrumb__wrap">
                <div class="container custom-container">
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-lg-8 col-md-10">
                            <div class="breadcrumb__wrap__content">
                                <h2 class="title"><?php echo e($portfolio->portfolio_name); ?></h2>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Главная</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($portfolio->portfolio_name); ?></li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="breadcrumb__wrap__icon">
                    <ul>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon01.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon02.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon03.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon04.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon05.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon06.png')); ?>" alt=""></li>
                    </ul>
                </div>
            </section>
            <!-- breadcrumb-area-end -->

            <!-- portfolio-details-area -->
            <section class="services__details">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="services__details__thumb">
  <img src=" <?php echo e(asset($portfolio->portfolio_image)); ?> " alt="">
                            </div>
                            <div class="services__details__content">
                                <h2 class="title"><?php echo e($portfolio->portfolio_title); ?></h2>
                                <p> <?php echo $portfolio->portfolio_description; ?> </p>


                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- portfolio-details-area-end -->
        </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mercial/Документы/blog/resources/views/frontend/protfolio_details.blade.php ENDPATH**/ ?>