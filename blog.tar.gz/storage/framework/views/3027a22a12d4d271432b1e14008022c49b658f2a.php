<?php $__env->startSection('main'); ?>

<?php $__env->startSection('title'); ?>
Напишите мне | Блог Владислава Озоровского
<?php $__env->stopSection(); ?>

 <main>

            <!-- breadcrumb-area -->
            <section class="breadcrumb__wrap">
                <div class="container custom-container">
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-lg-8 col-md-10">
                            <div class="breadcrumb__wrap__content">
                                <h2 class="title">Напишите мне</h2>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Главная</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Контакты</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="breadcrumb__wrap__icon">
                    <ul>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon01.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon02.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon03.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon04.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon05.png')); ?>" alt=""></li>
                        <li><img src="<?php echo e(asset('frontend/assets/img/icons/breadcrumb_icon06.png')); ?>" alt=""></li>
                    </ul>
                </div>
            </section>
            <!-- breadcrumb-area-end -->

            <!-- contact-map -->

<br>
            <!-- contact-area -->
            <div class="contact-area">
                <div class="container">
                    <form method="post" action="<?php echo e(route('store.message')); ?>" class="contact__form">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <input  name="name" type="text" placeholder="Ваше имя*">
                            </div>
                            <div class="col-md-6">
                                <input name="email" type="email" placeholder="Введите Ваш email*">
                            </div>
                            <div class="col-md-6">
                                <input  name="subject" type="text" placeholder="Тема*">
                            </div>
                            <div class="col-md-6">
                                <input  name="phone" type="text" placeholder="Ваш номер телефона*">
                            </div>
                        </div>
                        <textarea name="message" id="message" placeholder="Введите Ваше сообщение*"></textarea>
                        <button type="submit" class="btn">Отправить</button>
                    </form>
                </div>
            </div>
            <!-- contact-area-end -->





        </main>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mercial/Документы/blog/resources/views/frontend/contact.blade.php ENDPATH**/ ?>