<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © mercial.ru
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/mercial/Документы/blog/resources/views/admin/body/footer.blade.php ENDPATH**/ ?>